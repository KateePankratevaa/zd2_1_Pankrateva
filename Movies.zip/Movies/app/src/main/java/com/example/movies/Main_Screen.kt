package com.example.movies

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import com.example.movies.databinding.ActivityMainScreenBinding

class Main_Screen : Activity() {

    private lateinit var binding: ActivityMainScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }

    fun toChat(view: View) {
        val intent = Intent(this, Chat_List_Screen::class.java)
        startActivity(intent)
    }

    fun toMovies(view: View) {
        val intent = Intent(this, Movies_Screen::class.java)
        startActivity(intent)
    }
}